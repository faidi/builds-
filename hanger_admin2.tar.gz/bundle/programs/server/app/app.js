var require = meteorInstall({"lib":{"collections.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// lib/collections.js                                                                                   //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
module.export({                                                                                         // 1
  MessagesLanding: function () {                                                                        // 1
    return MessagesLanding;                                                                             // 1
  }                                                                                                     // 1
});                                                                                                     // 1
var Mongo = void 0;                                                                                     // 1
module.watch(require("meteor/mongo"), {                                                                 // 1
  Mongo: function (v) {                                                                                 // 1
    Mongo = v;                                                                                          // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
var MessagesLanding = new Mongo.Collection("messages_landing");                                         // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"carree":{"home_methods.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// server/carree/home_methods.js                                                                        //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var HTTP = void 0;                                                                                      // 1
module.watch(require("meteor/http"), {                                                                  // 1
  HTTP: function (v) {                                                                                  // 1
    HTTP = v;                                                                                           // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
Meteor.methods({                                                                                        // 3
  getFile: function (filePath) {                                                                        // 5
    console.log("chargement du fichier");                                                               // 6
    this.unblock();                                                                                     // 7
    var response;                                                                                       // 8
                                                                                                        //
    try {                                                                                               // 9
      response = HTTP.call('GET', 'https://raw.githubusercontent.com/faidi/Carree/master/' + filePath);
    } catch (e) {                                                                                       // 12
      response = e.response;                                                                            // 13
    } finally {                                                                                         // 14
      console.log(response);                                                                            // 15
      return response.content;                                                                          // 16
    }                                                                                                   // 17
  }                                                                                                     // 21
});                                                                                                     // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json",
    ".html"
  ]
});
require("./lib/collections.js");
require("./server/carree/home_methods.js");
//# sourceMappingURL=app.js.map
