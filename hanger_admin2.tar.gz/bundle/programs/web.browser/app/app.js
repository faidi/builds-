var require = meteorInstall({"client":{"scripts":{"lib":{"app.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/lib/app.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
    Meteor: function (v) {                                                                                            // 1
        Meteor = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 0);                                                                                                                // 1
module.watch(require("angular-meteor"));                                                                              // 1
module.watch(require("ng-showdown"));                                                                                 // 1
module.watch(require("angular-sanitize"));                                                                            // 1
var uiBootstrap = void 0;                                                                                             // 1
module.watch(require("angular-ui-bootstrap"), {                                                                       // 1
    "default": function (v) {                                                                                         // 1
        uiBootstrap = v;                                                                                              // 1
    }                                                                                                                 // 1
}, 1);                                                                                                                // 1
var ngAside = void 0;                                                                                                 // 1
module.watch(require("angular-aside"), {                                                                              // 1
    "default": function (v) {                                                                                         // 1
        ngAside = v;                                                                                                  // 1
    }                                                                                                                 // 1
}, 2);                                                                                                                // 1
var uiRouter = void 0;                                                                                                // 1
module.watch(require("angular-ui-router"), {                                                                          // 1
    "default": function (v) {                                                                                         // 1
        uiRouter = v;                                                                                                 // 1
    }                                                                                                                 // 1
}, 3);                                                                                                                // 1
module.watch(require("angular-moment"));                                                                              // 1
module.watch(require("angular-scroll"));                                                                              // 1
module.watch(require("angular-chart.js"));                                                                            // 1
module.watch(require("../../../node_modules/angular-aside-menu/src/aside-menu.js"));                                  // 1
module.watch(require("../../../node_modules/angular-aside-menu/dist/aside-menu.css"));                                // 1
var Loader = void 0;                                                                                                  // 1
module.watch(require("angular-ecmascript/module-loader"), {                                                           // 1
    "default": function (v) {                                                                                         // 1
        Loader = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 4);                                                                                                                // 1
var Routes = void 0;                                                                                                  // 1
module.watch(require("../routes"), {                                                                                  // 1
    "default": function (v) {                                                                                         // 1
        Routes = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 5);                                                                                                                // 1
var RoutesRunner = void 0;                                                                                            // 1
module.watch(require("../config"), {                                                                                  // 1
    "default": function (v) {                                                                                         // 1
        RoutesRunner = v;                                                                                             // 1
    }                                                                                                                 // 1
}, 6);                                                                                                                // 1
var LoginRunner = void 0;                                                                                             // 1
module.watch(require("../route_runs"), {                                                                              // 1
    "default": function (v) {                                                                                         // 1
        LoginRunner = v;                                                                                              // 1
    }                                                                                                                 // 1
}, 7);                                                                                                                // 1
var AppliCtrl = void 0;                                                                                               // 1
module.watch(require("../controllers/app.controller"), {                                                              // 1
    "default": function (v) {                                                                                         // 1
        AppliCtrl = v;                                                                                                // 1
    }                                                                                                                 // 1
}, 8);                                                                                                                // 1
var HomeCtrl = void 0;                                                                                                // 1
module.watch(require("../../components/carre/home/controller/home.controller"), {                                     // 1
    "default": function (v) {                                                                                         // 1
        HomeCtrl = v;                                                                                                 // 1
    }                                                                                                                 // 1
}, 9);                                                                                                                // 1
var PageContentCtrl = void 0;                                                                                         // 1
module.watch(require("../../components/carre/PageContent/controller/PageContent.controller"), {                       // 1
    "default": function (v) {                                                                                         // 1
        PageContentCtrl = v;                                                                                          // 1
    }                                                                                                                 // 1
}, 10);                                                                                                               // 1
var CalendarFilter = void 0;                                                                                          // 1
module.watch(require("../filters/calendar.filter"), {                                                                 // 1
    "default": function (v) {                                                                                         // 1
        CalendarFilter = v;                                                                                           // 1
    }                                                                                                                 // 1
}, 11);                                                                                                               // 1
var Navbar = void 0;                                                                                                  // 1
module.watch(require("../directives/navbar.directive"), {                                                             // 1
    "default": function (v) {                                                                                         // 1
        Navbar = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 12);                                                                                                               // 1
var InboxCount = void 0;                                                                                              // 1
module.watch(require("../factorys/inboxCount.factory"), {                                                             // 1
    "default": function (v) {                                                                                         // 1
        InboxCount = v;                                                                                               // 1
    }                                                                                                                 // 1
}, 13);                                                                                                               // 1
var ReadFile = void 0;                                                                                                // 1
module.watch(require("../sevices/readFile.factory"), {                                                                // 1
    "default": function (v) {                                                                                         // 1
        ReadFile = v;                                                                                                 // 1
    }                                                                                                                 // 1
}, 14);                                                                                                               // 1
//Déclarations                                                                                                        // 39
var App = 'Hanger-admin'; // App                                                                                      // 40
                                                                                                                      //
angular.module(App, ['duScroll', 'chart.js', 'angular-meteor', 'ui.router', 'ui.bootstrap', 'ngAside', 'asideModule', 'ng-showdown', 'ngSanitize']);
new Loader(App).load(Routes).load(RoutesRunner).load(LoginRunner) // .load(LoginCtrl)                                 // 45
.load(AppliCtrl) // .load(InboxCtrl)                                                                                  // 45
// .load(DashboardCtrl)                                                                                               // 52
// .load(AccountCtrl)                                                                                                 // 53
.load(HomeCtrl).load(PageContentCtrl).load(ReadFile).load(Navbar); // .load(CalendarFilter)                           // 45
// .load(InboxCount)                                                                                                  // 61
//    .load(LivraisonCtrl)                                                                                            // 63
                                                                                                                      //
function onReady() {                                                                                                  // 64
    angular.bootstrap(document, [App]);                                                                               // 65
} // Startup                                                                                                          // 66
                                                                                                                      //
                                                                                                                      //
if (Meteor.isCordova) {                                                                                               // 68
    angular.element(document).on('deviceready', onReady);                                                             // 69
} else {                                                                                                              // 71
    angular.element(document).ready(onReady);                                                                         // 73
}                                                                                                                     // 75
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"controllers":{"app.controller.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/controllers/app.controller.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
    "default": function () {                                                                                          // 1
        return AppliCtrl;                                                                                             // 1
    }                                                                                                                 // 1
});                                                                                                                   // 1
                                                                                                                      //
var _ = void 0;                                                                                                       // 1
                                                                                                                      //
module.watch(require("meteor/underscore"), {                                                                          // 1
    _: function (v) {                                                                                                 // 1
        _ = v;                                                                                                        // 1
    }                                                                                                                 // 1
}, 0);                                                                                                                // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
    Meteor: function (v) {                                                                                            // 1
        Meteor = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 1);                                                                                                                // 1
var moment = void 0;                                                                                                  // 1
module.watch(require("moment"), {                                                                                     // 1
    "default": function (v) {                                                                                         // 1
        moment = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 2);                                                                                                                // 1
var Controller = void 0;                                                                                              // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
    Controller: function (v) {                                                                                        // 1
        Controller = v;                                                                                               // 1
    }                                                                                                                 // 1
}, 3);                                                                                                                // 1
                                                                                                                      //
var AppliCtrl = function (_Controller) {                                                                              //
    (0, _inherits3.default)(AppliCtrl, _Controller);                                                                  //
                                                                                                                      //
    function AppliCtrl() {                                                                                            // 10
        (0, _classCallCheck3.default)(this, AppliCtrl);                                                               // 10
                                                                                                                      //
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                        // 10
            args[_key] = arguments[_key];                                                                             // 10
        }                                                                                                             // 10
                                                                                                                      //
        var _this = (0, _possibleConstructorReturn3.default)(this, _Controller.call.apply(_Controller, [this].concat(args)));
                                                                                                                      //
        _this.$reactive(_this).attach(_this.$scope);                                                                  // 12
                                                                                                                      //
        var self = _this;                                                                                             // 14
                                                                                                                      //
        _this.scrollTo = function (eID) {                                                                             // 16
            var startY = currentYPosition();                                                                          // 18
            var stopY = elmYPosition(eID);                                                                            // 19
            var distance = stopY > startY ? stopY - startY : startY - stopY;                                          // 20
            console.log(startY);                                                                                      // 21
            console.log(stopY);                                                                                       // 22
                                                                                                                      //
            if (distance < 100) {                                                                                     // 23
                scrollTo(0, stopY);                                                                                   // 24
                return;                                                                                               // 24
            }                                                                                                         // 25
                                                                                                                      //
            var speed = Math.round(distance / 40);                                                                    // 26
            if (speed >= 20) speed = 20;                                                                              // 27
            var step = Math.round(distance / 25);                                                                     // 28
            var leapY = stopY > startY ? startY + step : startY - step;                                               // 29
            var timer = 0;                                                                                            // 30
                                                                                                                      //
            if (stopY > startY) {                                                                                     // 31
                for (var i = startY; i < stopY; i += step) {                                                          // 32
                    setTimeout("window.scrollTo(0, " + leapY + ")", timer * speed);                                   // 33
                    leapY += step;                                                                                    // 34
                    if (leapY > stopY) leapY = stopY;                                                                 // 34
                    timer++;                                                                                          // 34
                }                                                                                                     // 35
                                                                                                                      //
                return;                                                                                               // 35
            }                                                                                                         // 36
                                                                                                                      //
            for (var i = startY; i > stopY; i -= step) {                                                              // 37
                setTimeout("window.scrollTo(0, " + leapY + ")", timer * speed);                                       // 38
                leapY -= step;                                                                                        // 39
                if (leapY < stopY) leapY = stopY;                                                                     // 39
                timer++;                                                                                              // 39
            }                                                                                                         // 40
                                                                                                                      //
            function currentYPosition() {                                                                             // 42
                // Firefox, Chrome, Opera, Safari                                                                     // 43
                if (self.pageYOffset) return self.pageYOffset; // Internet Explorer 6 - standards mode                // 44
                                                                                                                      //
                if (document.documentElement && document.documentElement.scrollTop) return document.documentElement.scrollTop; // Internet Explorer 6, 7 and 8
                                                                                                                      //
                if (document.body.scrollTop) return document.body.scrollTop;                                          // 49
                return 0;                                                                                             // 50
            }                                                                                                         // 51
                                                                                                                      //
            function elmYPosition(eID) {                                                                              // 53
                var elm = document.getElementById(eID);                                                               // 54
                var y = elm.offsetTop;                                                                                // 55
                var node = elm;                                                                                       // 56
                                                                                                                      //
                while (node.offsetParent && node.offsetParent != document.body) {                                     // 57
                    node = node.offsetParent;                                                                         // 58
                    y += node.offsetTop;                                                                              // 59
                }                                                                                                     // 60
                                                                                                                      //
                return y;                                                                                             // 60
            }                                                                                                         // 61
        }; //                                                                                                         // 63
        // this.helpers({                                                                                             // 71
        //                                                                                                            // 72
        //                                                                                                            // 73
        //                                                                                                            // 74
        //                                                                                                            // 75
        //     });                                                                                                    // 76
                                                                                                                      //
                                                                                                                      //
        return _this;                                                                                                 // 10
    }                                                                                                                 // 78
                                                                                                                      //
    return AppliCtrl;                                                                                                 //
}(Controller);                                                                                                        //
                                                                                                                      //
AppliCtrl.$inject = ['$aside', '$location', '$animate', '$state', '$reactive', '$uibModal', '$location', '$anchorScroll'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"directives":{"navbar.directive.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/directives/navbar.directive.js                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
	"default": function () {                                                                                             // 1
		return Navbar;                                                                                                      // 1
	}                                                                                                                    // 1
});                                                                                                                   // 1
var Directive = void 0;                                                                                               // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
	Directive: function (v) {                                                                                            // 1
		Directive = v;                                                                                                      // 1
	}                                                                                                                    // 1
}, 0);                                                                                                                // 1
                                                                                                                      //
var Navbar = function (_Directive) {                                                                                  //
	(0, _inherits3.default)(Navbar, _Directive);                                                                         //
                                                                                                                      //
	function Navbar() {                                                                                                  // 5
		(0, _classCallCheck3.default)(this, Navbar);                                                                        // 5
                                                                                                                      //
		for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                              // 5
			args[_key] = arguments[_key];                                                                                      // 5
		}                                                                                                                   // 5
                                                                                                                      //
		var _this = (0, _possibleConstructorReturn3.default)(this, _Directive.call.apply(_Directive, [this].concat(args)));
                                                                                                                      //
		_this.restrict = 'C';                                                                                               // 7
		return _this;                                                                                                       // 5
	}                                                                                                                    // 8
                                                                                                                      //
	Navbar.prototype.link = function () {                                                                                //
		function link(scope, elem, attrs) {                                                                                 //
			scope.win = angular.element(this.$window); // scope.topClass = 300; // get CSS class from directive's attribute value
			// scope.offsetTop = 200;                                                                                          // 17
                                                                                                                      //
			scope.win.on('scroll', function (e) {                                                                              // 19
				if (this.scrollY > 180) {                                                                                         // 25
					elem.removeClass("hidenav");                                                                                     // 26
					elem.addClass("shownav");                                                                                        // 27
				} else {                                                                                                          // 28
					elem.removeClass("shownav");                                                                                     // 29
					elem.addClass("hidenav");                                                                                        // 30
				} // console.log(scope.win.scrollHeight);                                                                         // 31
				// if (scope.win.scrollTop + scope.win.offsetHeight > scope.win.scrollHeight) {                                   // 33
				//      console.log("je suis dans le if");                                                                        // 34
				// }                                                                                                              // 35
				// elem[(scope.win.scrollTop() >= scope.offsetTop) ? 'addClass' : 'removeClass'](scope.topClass);                 // 36
                                                                                                                      //
			});                                                                                                                // 37
		}                                                                                                                   // 39
                                                                                                                      //
		return link;                                                                                                        //
	}();                                                                                                                 //
                                                                                                                      //
	return Navbar;                                                                                                       //
}(Directive);                                                                                                         //
                                                                                                                      //
Navbar.$inject = ["$window"];                                                                                         // 46
Navbar.$name = 'showonscroll';                                                                                        // 48
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"factorys":{"inboxCount.factory.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/factorys/inboxCount.factory.js                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return InboxCount;                                                                                                // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Service = void 0;                                                                                                 // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Service: function (v) {                                                                                             // 1
    Service = v;                                                                                                      // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
                                                                                                                      //
var InboxCount = function (_Service) {                                                                                //
  (0, _inherits3.default)(InboxCount, _Service);                                                                      //
                                                                                                                      //
  function InboxCount() {                                                                                             // 5
    (0, _classCallCheck3.default)(this, InboxCount);                                                                  // 5
    return (0, _possibleConstructorReturn3.default)(this, _Service.apply(this, arguments));                           // 5
  }                                                                                                                   // 8
                                                                                                                      //
  InboxCount.prototype.getCounts = function () {                                                                      //
    function getCounts() {                                                                                            //
      var deffered = this.$q.defer();                                                                                 // 12
      var factory = false;                                                                                            // 14
      Meteor.call('getMessagesCount', function (err, result) {                                                        // 16
        if (result) {                                                                                                 // 17
          deffered.resolve(result);                                                                                   // 19
        } else {                                                                                                      // 20
          deffered.reject('Impossible de récupérer le nombre de messages');                                           // 22
        }                                                                                                             // 23
                                                                                                                      //
        ;                                                                                                             // 23
      });                                                                                                             // 24
      return deffered.promise;                                                                                        // 25
    }                                                                                                                 // 27
                                                                                                                      //
    return getCounts;                                                                                                 //
  }();                                                                                                                //
                                                                                                                      //
  InboxCount.prototype.getUnreadCounts = function () {                                                                //
    function getUnreadCounts() {                                                                                      //
      var deffered = this.$q.defer();                                                                                 // 30
      Meteor.call('getUnreadMessagesCount', function (err, result) {                                                  // 34
        if (result) {                                                                                                 // 35
          deffered.resolve(result);                                                                                   // 37
        } else {                                                                                                      // 38
          deffered.reject('Impossible de récupérer le nombre des  messages non lu');                                  // 40
        }                                                                                                             // 41
                                                                                                                      //
        ;                                                                                                             // 41
      });                                                                                                             // 42
      return deffered.promise;                                                                                        // 44
    }                                                                                                                 // 45
                                                                                                                      //
    return getUnreadCounts;                                                                                           //
  }();                                                                                                                //
                                                                                                                      //
  return InboxCount;                                                                                                  //
}(Service);                                                                                                           //
                                                                                                                      //
InboxCount.$name = 'InboxCount';                                                                                      // 50
InboxCount.$inject = ['$rootScope', '$q'];                                                                            // 51
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"filters":{"calendar.filter.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/filters/calendar.filter.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
    "default": function () {                                                                                          // 1
        return CalendarFilter;                                                                                        // 1
    }                                                                                                                 // 1
});                                                                                                                   // 1
var moment = void 0;                                                                                                  // 1
module.watch(require("moment"), {                                                                                     // 1
    "default": function (v) {                                                                                         // 1
        moment = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 0);                                                                                                                // 1
var Filter = void 0;                                                                                                  // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
    Filter: function (v) {                                                                                            // 1
        Filter = v;                                                                                                   // 1
    }                                                                                                                 // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var CalendarFilter = function (_Filter) {                                                                             //
    (0, _inherits3.default)(CalendarFilter, _Filter);                                                                 //
                                                                                                                      //
    function CalendarFilter() {                                                                                       //
        (0, _classCallCheck3.default)(this, CalendarFilter);                                                          //
        return (0, _possibleConstructorReturn3.default)(this, _Filter.apply(this, arguments));                        //
    }                                                                                                                 //
                                                                                                                      //
    CalendarFilter.prototype.filter = function () {                                                                   //
        function filter(time) {                                                                                       //
            if (!time) return;                                                                                        // 6
            moment.locale('fr', {                                                                                     // 7
                months: "janvier_février_mars_avril_mai_juin_juillet_août_septembre_octobre_novembre_décembre".split("_"),
                monthsShort: "janv._févr._mars_avr._mai_juin_juil._août_sept._oct._nov._déc.".split("_"),             // 9
                weekdays: "dimanche_lundi_mardi_mercredi_jeudi_vendredi_samedi".split("_"),                           // 10
                weekdaysShort: "dim._lun._mar._mer._jeu._ven._sam.".split("_"),                                       // 11
                weekdaysMin: "Di_Lu_Ma_Me_Je_Ve_Sa".split("_"),                                                       // 12
                longDateFormat: {                                                                                     // 13
                    LT: "HH:mm",                                                                                      // 14
                    LTS: "HH:mm:ss",                                                                                  // 15
                    L: "DD/MM/YYYY",                                                                                  // 16
                    LL: "D MMMM YYYY",                                                                                // 17
                    LLL: "D MMMM YYYY LT",                                                                            // 18
                    LLLL: "dddd D MMMM YYYY LT"                                                                       // 19
                },                                                                                                    // 13
                calendar: {                                                                                           // 21
                    sameDay: "[Aujourd'hui à] LT",                                                                    // 22
                    nextDay: '[Demain à] LT',                                                                         // 23
                    nextWeek: 'dddd [à] LT',                                                                          // 24
                    lastDay: '[Hier à] LT',                                                                           // 25
                    lastWeek: 'dddd [dernier à] LT',                                                                  // 26
                    sameElse: 'L'                                                                                     // 27
                },                                                                                                    // 21
                relativeTime: {                                                                                       // 29
                    future: "dans %s",                                                                                // 30
                    past: "il y a %s",                                                                                // 31
                    s: "quelques secondes",                                                                           // 32
                    m: "une minute",                                                                                  // 33
                    mm: "%d minutes",                                                                                 // 34
                    h: "une heure",                                                                                   // 35
                    hh: "%d heures",                                                                                  // 36
                    d: "un jour",                                                                                     // 37
                    dd: "%d jours",                                                                                   // 38
                    M: "un mois",                                                                                     // 39
                    MM: "%d mois",                                                                                    // 40
                    y: "une année",                                                                                   // 41
                    yy: "%d années"                                                                                   // 42
                },                                                                                                    // 29
                ordinalParse: /\d{1,2}(er|ème)/,                                                                      // 44
                ordinal: function (number) {                                                                          // 45
                    return number + (number === 1 ? 'er' : 'ème');                                                    // 46
                },                                                                                                    // 47
                meridiemParse: /PD|MD/,                                                                               // 48
                isPM: function (input) {                                                                              // 49
                    return input.charAt(0) === 'M';                                                                   // 50
                },                                                                                                    // 51
                // in case the meridiem units are not separated around 12, then implement                             // 52
                // this function (look at locale/id.js for an example)                                                // 53
                // meridiemHour : function (hour, meridiem) {                                                         // 54
                //     return /* 0-23 hour, given meridiem token and hour 1-12 */                                     // 55
                // },                                                                                                 // 56
                meridiem: function (hours, minutes, isLower) {                                                        // 57
                    return hours < 12 ? 'PD' : 'MD';                                                                  // 58
                },                                                                                                    // 59
                week: {                                                                                               // 60
                    dow: 1,                                                                                           // 61
                    // Monday is the first day of the week.                                                           // 61
                    doy: 4 // The week that contains Jan 4th is the first week of the year.                           // 62
                                                                                                                      //
                }                                                                                                     // 60
            });                                                                                                       // 7
            return moment(time).locale("fr").format("DD MMMM YYYY à hh:mm"); /*return Moment(time).locale("fr").calendar(null, {
                                                                                sameDay: '[Aujourdhui à] HH:mm',      //
                                                                              nextDay: '[Demain à] HH:mm',            //
                                                                              nextWeek: 'dddd [à] HH:mm',             //
                                                                              lastDay: '[Hier à] HH:mm',              //
                                                                              lastWeek: 'dddd [dernier à] HH:mm',     //
                                                                              sameElse: 'L'                           //
                                                                              });                                     //
                                                                             */                                       //
        }                                                                                                             // 80
                                                                                                                      //
        return filter;                                                                                                //
    }();                                                                                                              //
                                                                                                                      //
    return CalendarFilter;                                                                                            //
}(Filter);                                                                                                            //
                                                                                                                      //
CalendarFilter.$name = 'calendar';                                                                                    // 83
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"sevices":{"inboxCount.factory.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/sevices/inboxCount.factory.js                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return InboxCount;                                                                                                // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Service = void 0;                                                                                                 // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Service: function (v) {                                                                                             // 1
    Service = v;                                                                                                      // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
                                                                                                                      //
var InboxCount = function (_Service) {                                                                                //
  (0, _inherits3.default)(InboxCount, _Service);                                                                      //
                                                                                                                      //
  function InboxCount() {                                                                                             // 5
    (0, _classCallCheck3.default)(this, InboxCount);                                                                  // 5
    return (0, _possibleConstructorReturn3.default)(this, _Service.apply(this, arguments));                           // 5
  }                                                                                                                   // 8
                                                                                                                      //
  InboxCount.prototype.getCounts = function () {                                                                      //
    function getCounts() {                                                                                            //
      var deffered = this.$q.defer();                                                                                 // 12
      var factory = false;                                                                                            // 14
      Meteor.call('getMessagesCount', function (err, result) {                                                        // 16
        if (result) {                                                                                                 // 17
          factory.count = result;                                                                                     // 18
          deffered.resolve(factory);                                                                                  // 19
        } else {                                                                                                      // 20
          console.log('Impossible de récupérer le nombre de messages');                                               // 22
        }                                                                                                             // 23
                                                                                                                      //
        ;                                                                                                             // 23
      });                                                                                                             // 24
      return deffered.promise;                                                                                        // 25
    }                                                                                                                 // 26
                                                                                                                      //
    return getCounts;                                                                                                 //
  }();                                                                                                                //
                                                                                                                      //
  return InboxCount;                                                                                                  //
}(Service);                                                                                                           //
                                                                                                                      //
InboxCount.$name = 'InboxCount';                                                                                      // 31
InboxCount.$inject = ['$rootScope', '$q'];                                                                            // 32
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"readFile.factory.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/sevices/readFile.factory.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return ReadFile;                                                                                                  // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Service = void 0;                                                                                                 // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Service: function (v) {                                                                                             // 1
    Service = v;                                                                                                      // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
                                                                                                                      //
var ReadFile = function (_Service) {                                                                                  //
  (0, _inherits3.default)(ReadFile, _Service);                                                                        //
                                                                                                                      //
  function ReadFile() {                                                                                               // 5
    (0, _classCallCheck3.default)(this, ReadFile);                                                                    // 5
    return (0, _possibleConstructorReturn3.default)(this, _Service.apply(this, arguments));                           // 5
  }                                                                                                                   // 8
                                                                                                                      //
  ReadFile.prototype.getFileContent = function () {                                                                   //
    function getFileContent(filePath) {                                                                               //
      var deffered = this.$q.defer();                                                                                 // 12
      console.log("dans le service");                                                                                 // 13
      var factory;                                                                                                    // 14
      Meteor.call('getFile', filePath, function (err, result) {                                                       // 16
        if (result) {                                                                                                 // 17
          factory = result;                                                                                           // 19
          deffered.resolve(factory);                                                                                  // 20
        } else {                                                                                                      // 21
          console.log('Impossible de récupérer le Fichier');                                                          // 23
        }                                                                                                             // 24
                                                                                                                      //
        ;                                                                                                             // 24
      });                                                                                                             // 25
      return deffered.promise;                                                                                        // 26
    }                                                                                                                 // 27
                                                                                                                      //
    return getFileContent;                                                                                            //
  }();                                                                                                                //
                                                                                                                      //
  return ReadFile;                                                                                                    //
}(Service);                                                                                                           //
                                                                                                                      //
ReadFile.$name = 'ReadFile';                                                                                          // 32
ReadFile.$inject = ['$rootScope', '$q'];                                                                              // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/config.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return RoutesRunner;                                                                                              // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Runner = void 0;                                                                                                  // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Runner: function (v) {                                                                                              // 1
    Runner = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var RoutesRunner = function (_Runner) {                                                                               //
  (0, _inherits3.default)(RoutesRunner, _Runner);                                                                     //
                                                                                                                      //
  function RoutesRunner() {                                                                                           //
    (0, _classCallCheck3.default)(this, RoutesRunner);                                                                //
    return (0, _possibleConstructorReturn3.default)(this, _Runner.apply(this, arguments));                            //
  }                                                                                                                   //
                                                                                                                      //
  RoutesRunner.prototype.run = function () {                                                                          //
    function run() {                                                                                                  //
      var _this2 = this;                                                                                              // 5
                                                                                                                      //
      this.$rootScope.$on('$stateChangeSuccess', function (event) {                                                   // 12
        _this2.$anchorScroll('top');                                                                                  // 13
      });                                                                                                             // 16
    }                                                                                                                 // 18
                                                                                                                      //
    return run;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  return RoutesRunner;                                                                                                //
}(Runner);                                                                                                            //
                                                                                                                      //
RoutesRunner.$inject = ['$rootScope', '$anchorScroll', '$state', '$window'];                                          // 21
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"route_runs.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/route_runs.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return LoginRunner;                                                                                               // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Runner = void 0;                                                                                                  // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Runner: function (v) {                                                                                              // 1
    Runner = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var LoginRunner = function (_Runner) {                                                                                //
  (0, _inherits3.default)(LoginRunner, _Runner);                                                                      //
                                                                                                                      //
  function LoginRunner() {                                                                                            //
    (0, _classCallCheck3.default)(this, LoginRunner);                                                                 //
    return (0, _possibleConstructorReturn3.default)(this, _Runner.apply(this, arguments));                            //
  }                                                                                                                   //
                                                                                                                      //
  // static $inject = ['$rootScope', '$state']                                                                        // 4
  LoginRunner.prototype.run = function () {                                                                           //
    function run() {                                                                                                  //
      var _this2 = this;                                                                                              // 5
                                                                                                                      //
      // let self=this;                                                                                               // 7
      this.$rootScope.$on('$stateChangeError', function () {                                                          // 13
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                        // 13
          args[_key] = arguments[_key];                                                                               // 13
        }                                                                                                             // 13
                                                                                                                      //
        var err = _.last(args);                                                                                       // 14
                                                                                                                      //
        if (err === 'AUTH_REQUIRED') {                                                                                // 16
          _this2.$state.go("login");                                                                                  // 17
        }                                                                                                             // 18
      });                                                                                                             // 19
    }                                                                                                                 // 20
                                                                                                                      //
    return run;                                                                                                       //
  }();                                                                                                                //
                                                                                                                      //
  return LoginRunner;                                                                                                 //
}(Runner);                                                                                                            //
                                                                                                                      //
LoginRunner.$inject = ['$rootScope', '$state'];                                                                       // 23
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/scripts/routes.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return RoutesConfig;                                                                                              // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Config = void 0;                                                                                                  // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Config: function (v) {                                                                                              // 1
    Config = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
                                                                                                                      //
var RoutesConfig = function (_Config) {                                                                               //
  (0, _inherits3.default)(RoutesConfig, _Config);                                                                     //
                                                                                                                      //
  function RoutesConfig() {                                                                                           //
    (0, _classCallCheck3.default)(this, RoutesConfig);                                                                //
    return (0, _possibleConstructorReturn3.default)(this, _Config.apply(this, arguments));                            //
  }                                                                                                                   //
                                                                                                                      //
  /*constructor() {                                                                                                   // 4
   super(...arguments);                                                                                               //
   this.isAuthorized = ['$auth', this.isAuthorized.bind(this)];                                                       //
   }                                                                                                                  //
   */RoutesConfig.prototype.configure = function () {                                                                 //
    function configure() {                                                                                            //
      this.$stateProvider.state('app', {                                                                              // 10
        url: '/app',                                                                                                  // 13
        abstract: true,                                                                                               // 14
        templateUrl: 'client/templates/sidemenu.html',                                                                // 15
        controller: 'AppliCtrl as Appli'                                                                              // 16
      }).state('app.carreehome', {                                                                                    // 12
        url: '/carreehome',                                                                                           // 30
        views: {                                                                                                      // 32
          'side-menu-content': {                                                                                      // 33
            templateUrl: 'client/components/carre/home/templates/home.html',                                          // 35
            controller: 'HomeCtrl as carreHome'                                                                       // 36
          }                                                                                                           // 34
        }                                                                                                             // 32
      }).state('app.pageContent', {                                                                                   // 29
        url: '/content/:contentPath',                                                                                 // 41
        views: {                                                                                                      // 43
          'side-menu-content': {                                                                                      // 44
            templateUrl: 'client/components/carre/PageContent/templates/PageContent.html',                            // 46
            controller: 'PageContentCtrl as PageContent'                                                              // 47
          }                                                                                                           // 45
        }                                                                                                             // 43
      });                                                                                                             // 40
      this.$urlRouterProvider.otherwise('app/carreehome');                                                            // 54
    }                                                                                                                 // 55
                                                                                                                      //
    return configure;                                                                                                 //
  }();                                                                                                                //
                                                                                                                      //
  return RoutesConfig;                                                                                                //
}(Config);                                                                                                            //
                                                                                                                      //
RoutesConfig.$inject = ['$stateProvider', '$urlRouterProvider'];                                                      // 57
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"components":{"carre":{"PageContent":{"controller":{"PageContent.controller.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/components/carre/PageContent/controller/PageContent.controller.js                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return PageContentCtrl;                                                                                           // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
var _ = void 0;                                                                                                       // 1
                                                                                                                      //
module.watch(require("meteor/underscore"), {                                                                          // 1
  _: function (v) {                                                                                                   // 1
    _ = v;                                                                                                            // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var moment = void 0;                                                                                                  // 1
module.watch(require("moment"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    moment = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
var Controller = void 0;                                                                                              // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Controller: function (v) {                                                                                          // 1
    Controller = v;                                                                                                   // 1
  }                                                                                                                   // 1
}, 3);                                                                                                                // 1
                                                                                                                      //
var PageContentCtrl = function (_Controller) {                                                                        //
  (0, _inherits3.default)(PageContentCtrl, _Controller);                                                              //
                                                                                                                      //
  function PageContentCtrl() {                                                                                        // 10
    (0, _classCallCheck3.default)(this, PageContentCtrl);                                                             // 10
                                                                                                                      //
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                            // 10
      args[_key] = arguments[_key];                                                                                   // 10
    }                                                                                                                 // 10
                                                                                                                      //
    var _this = (0, _possibleConstructorReturn3.default)(this, _Controller.call.apply(_Controller, [this].concat(args)));
                                                                                                                      //
    _this.$reactive(_this).attach(_this.$scope);                                                                      // 12
                                                                                                                      //
    var self = _this;                                                                                                 // 13
    _this.$rootScope.title = "Mon titre";                                                                             // 14
    _this.currentMD = "";                                                                                             // 16
    _this.mdStr = "";                                                                                                 // 17
    _this.headlines = [];                                                                                             // 18
    _this.fileloading = false; //loading file content                                                                 // 19
                                                                                                                      //
    _this.ReadFile.getFileContent(_this.$stateParams.contentPath).then(function (res) {                               // 24
      self.currentPage = self.$stateParams.contentPath;                                                               // 27
      self.fileloading = false;                                                                                       // 28
      self.mdStr = res;                                                                                               // 29
      self.currentMD = self.$showdown.makeHtml(res);                                                                  // 30
      var headlinesELT = self.createElement(self.currentMD);                                                          // 31
                                                                                                                      //
      _.each(headlinesELT.querySelectorAll('h1, h2'), function (e) {                                                  // 33
        self.headlines.push({                                                                                         // 34
          level: e.tagName[1],                                                                                        // 35
          label: angular.element(e).text(),                                                                           // 36
          element: e                                                                                                  // 37
        });                                                                                                           // 34
      });                                                                                                             // 39
                                                                                                                      //
      console.log(self.headlines);                                                                                    // 41
    }, function (msg) {                                                                                               // 43
      self.fileloading = false;                                                                                       // 46
      alert(msg);                                                                                                     // 47
    });                                                                                                               // 48
                                                                                                                      //
    return _this;                                                                                                     // 10
  }                                                                                                                   // 53
                                                                                                                      //
  PageContentCtrl.prototype.createElement = function () {                                                             //
    function createElement(str) {                                                                                     //
      var frag = self.document.createDocumentFragment();                                                              // 57
      var elem = self.document.createElement('div');                                                                  // 58
      elem.innerHTML = str;                                                                                           // 59
                                                                                                                      //
      while (elem.childNodes[0]) {                                                                                    // 60
        frag.appendChild(elem.childNodes[0]);                                                                         // 61
      }                                                                                                               // 62
                                                                                                                      //
      return frag;                                                                                                    // 63
    }                                                                                                                 // 64
                                                                                                                      //
    return createElement;                                                                                             //
  }();                                                                                                                //
                                                                                                                      //
  return PageContentCtrl;                                                                                             //
}(Controller);                                                                                                        //
                                                                                                                      //
PageContentCtrl.$inject = ['$document', '$stateParams', 'ReadFile', '$aside', '$location', '$animate', '$state', '$reactive', '$uibModal', '$location', '$anchorScroll', '$rootScope', '$showdown'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"templates":{"PageContent.html":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/components/carre/PageContent/templates/PageContent.html                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
      if (Meteor.isServer) return;                                                                                    // 2
                                                                                                                      // 3
      var templateUrl = "/client/components/carre/PageContent/templates/PageContent.html";                            // 4
      var template = " <style media=\"screen\">body{background-color:#487eb0;font-family:'Open Sans'}.navbar{height:7%;background-color:#487eb0;border-bottom:grey}</style> <!-- USING BOOTSTRAP 3.0.3 --> <div class=\"navbar navbar-inverse navbar-fixed-top\"> <div class=\"container\"> <div class=\"navbar-header\"> <a class=\"navbar-brand\" href=\"#\"> <img src=\"icons_imgs/logo_socle_big_data_v3.png\" height=\"50\" alt=\"\" style=\"position:fixed;top:5px;left:8%;width:8%;height:10%;background-color:#fff;border-bottom-left-radius:10%;border-radius:10%;padding:4px;border-width:4px;border-style:solid;border-color:#487eb0\"> </a> </div> <img src=\"icons_imgs/SG.png\" height=\"20\" style=\"position:fixed;top:10px;right:10px\"> </div> </div> <!-- <div class=\"\" style=\"background-color:red;height:80px;position:fixed;top:0px;width:100%;\">\n\n</div> --> <div style=\"padding-top:6%\"> <div class=\"row\"> <div class=\"col-lg-3\" style=\"height:90vh;position:fixed;left:5px;top:8%;background-color:#273c75;border-top-left-radius:40px\"> <nav class=\"menu\"> <h3 style=\"color:#fff;font-weight:800\">Sommaire</h3> </nav> <div class=\"\" style=\"height:100vh;overflow:scroll\"> <nav class=\"menu\" du-spy-context du-scroll-container=\"scroll-container\"> <ul class=\"list-group\" style=\"padding:10px\"> <li ng-repeat=\"headline in  PageContent.headlines\" ng-init=\"eId= headline.element.id\"> <a class=\"sect\" style=\"color:#fff;font-weight:800;font-size:1.5em\" ng-if=\"headline.level == '1'\" href=\"#{{eId}}\" du-smooth-scroll> {{headline.label}} </a> <p style=\"padding-left:20px;font-size:1em\" ng-if=\"headline.level == '2'\"> <a style=\"color:#fff;font-weight:800\" class=\"sect\" href=\"#{{eId}}\" du-smooth-scroll> {{headline.label}} </a> </p> </li> </ul> </nav> </div> </div> <div class=\"col-lg-9\" style=\"position:fixed;height:90%;top:8%;right:5px;background-color:#dff9fb\"> <a href=\"https://github.com/faidi/Carree/edit/master/{{PageContent.currentPage}}\" target=\"_blank\" class=\"pull-right\"><i class=\"glyphicon glyphicon-edit\"></i> Editer </a> <div class=\"\" style=\"height:100vh;overflow:scroll;padding-bottom:200px\" id=\"scroll-container\"> <div markdown-to-html=\"PageContent.mdStr\"> </div> </div> </div> </div> </div> ";
                                                                                                                      // 6
      angular.module('angular-templates')                                                                             // 7
        .run(['$templateCache', function($templateCache) {                                                            // 8
          $templateCache.put(templateUrl, template);                                                                  // 9
        }]);                                                                                                          // 10
                                                                                                                      // 11
      module.exports = {};                                                                                            // 12
      module.exports.__esModule = true;                                                                               // 13
      module.exports.default = templateUrl;                                                                           // 14
                                                                                                                      // 15
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"home":{"controller":{"home.controller.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/components/carre/home/controller/home.controller.js                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
module.export({                                                                                                       // 1
  "default": function () {                                                                                            // 1
    return HomeCtrl;                                                                                                  // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
                                                                                                                      //
var _ = void 0;                                                                                                       // 1
                                                                                                                      //
module.watch(require("meteor/underscore"), {                                                                          // 1
  _: function (v) {                                                                                                   // 1
    _ = v;                                                                                                            // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var moment = void 0;                                                                                                  // 1
module.watch(require("moment"), {                                                                                     // 1
  "default": function (v) {                                                                                           // 1
    moment = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 2);                                                                                                                // 1
var Controller = void 0;                                                                                              // 1
module.watch(require("angular-ecmascript/module-helpers"), {                                                          // 1
  Controller: function (v) {                                                                                          // 1
    Controller = v;                                                                                                   // 1
  }                                                                                                                   // 1
}, 3);                                                                                                                // 1
                                                                                                                      //
var HomeCtrl = function (_Controller) {                                                                               //
  (0, _inherits3.default)(HomeCtrl, _Controller);                                                                     //
                                                                                                                      //
  function HomeCtrl() {                                                                                               // 10
    (0, _classCallCheck3.default)(this, HomeCtrl);                                                                    // 10
                                                                                                                      //
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                            // 10
      args[_key] = arguments[_key];                                                                                   // 10
    }                                                                                                                 // 10
                                                                                                                      //
    var _this = (0, _possibleConstructorReturn3.default)(this, _Controller.call.apply(_Controller, [this].concat(args)));
                                                                                                                      //
    _this.$reactive(_this).attach(_this.$scope);                                                                      // 12
                                                                                                                      //
    var self = _this;                                                                                                 // 13
    _this.$rootScope.title = "Mon titre";                                                                             // 14
    _this.currentMD = "";                                                                                             // 16
    _this.stripped = ""; //                                                                                           // 17
    // this.helpers({                                                                                                 // 19
    //                                                                                                                // 20
    //                                                                                                                // 21
    //                                                                                                                // 22
    //     });                                                                                                        // 23
                                                                                                                      //
    _this.fileloading = false;                                                                                        // 24
    console.log("test"); // this.getFileContent=()=>{                                                                 // 25
    //       self.fileloading=false;                                                                                  // 27
    //       console.log("début du chargement fichier");                                                              // 28
    //       this.ReadFile.getFileContent("contracts.md")                                                             // 29
    //       .then(                                                                                                   // 30
    //           function(res) {                                                                                      // 31
    //             self.fileloading=false;                                                                            // 32
    //             console.log("fin du chargement 2",res);                                                            // 33
    //                                                                                                                // 34
    //           },                                                                                                   // 35
    //           function(msg) {                                                                                      // 36
    //                                                                                                                // 37
    //               self.fileloading=false;                                                                          // 38
    //             alert(msg)                                                                                         // 39
    //           }                                                                                                    // 40
    //       )                                                                                                        // 41
    //     }                                                                                                          // 42
                                                                                                                      //
    _this.getFileContent = function (message_id) {                                                                    // 44
      _this.ReadFile.getFileContent("contracts.md").then(function (res) {                                             // 46
        self.fileloading = false;                                                                                     // 49
        self.currentMD = res;                                                                                         // 50
        console.log("fin du chargement 2", res);                                                                      // 51
        self.stripped = self.$showdown.stripHtml(res);                                                                // 52
      }, function (msg) {                                                                                             // 53
        self.fileloading = false;                                                                                     // 56
        alert(msg);                                                                                                   // 57
      }); // Meteor.call('getFile',"contracts.md"  ,(err, result) => {                                                // 58
      //     if (result) {                                                                                            // 61
      //       console.log(result);                                                                                   // 62
      //     }                                                                                                        // 63
      //     else{                                                                                                    // 64
      //       alert(err)                                                                                             // 65
      //     };                                                                                                       // 66
      //   });                                                                                                        // 67
                                                                                                                      //
    };                                                                                                                // 69
                                                                                                                      //
    return _this;                                                                                                     // 10
  }                                                                                                                   // 71
                                                                                                                      //
  return HomeCtrl;                                                                                                    //
}(Controller);                                                                                                        //
                                                                                                                      //
HomeCtrl.$inject = ['ReadFile', '$aside', '$location', '$animate', '$state', '$reactive', '$uibModal', '$location', '$anchorScroll', '$rootScope', '$showdown'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"templates":{"home.html":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/components/carre/home/templates/home.html                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
      if (Meteor.isServer) return;                                                                                    // 2
                                                                                                                      // 3
      var templateUrl = "/client/components/carre/home/templates/home.html";                                          // 4
      var template = "<!-- <div class=\"bg-home\" style=\"text-alight:center; height:100vh;\n\">\n\n<img src=\"icons_imgs/SG.png\"  height=\"30\"  style=\"position:fixed;top:10px;right:10px;\">\n\n\n<div style=\"width:100vw;height:45vh;float:left !important;\">\n<div style=\"height:100%;width:15vw;float:left; text-align:center;\">\n<div class=\"vcenter\" style=\"height:3vh;width:100%;\">\n<p style=\"text-align:center;height:100%;color:white;font-weight:900;\">COLLECTE</p>\n</div>\n<img src=\"icons_imgs/sashboard.png\" alt=\"\" style=\"height:40%; width:100%;padding-top:10%;padding-left:12%;padding-right:12%;\">\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:25%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">Collecte de données en streaming</p>\n</div>\n</a>\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:30%;width:100%;text-align:center;background-color:#3498db;\">\n<p style=\"color:#dcdde1;font-weight:900;\">Collecte de données en streaming</p>\n</div>\n</a>\n</div>\n\n\n\n\n<div style=\"height:35vh;width:70vw;float:left;text-align:center;\">\n\n\n\n<div style=\"float:left;width:50%;height:25vh;\">\n<div class=\"vcenter\" style=\"height:10%;width:100%;\">\n<p style=\"text-align:center;height:100%;color:white;font-weight:900;\">USAGE DES DONNEES</p>\n</div>\n\n<div  style=\"height:35vh;width:33%;float:left;\">\n\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:33%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">\nAnalyse batch\n</p>\n</div>\n</a>\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:33%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">\nAnalyse prédictive\n</p>\n</div>\n</a>\n\n</div>\n<div   style=\"height:100%;width:33%;float:left;padding:5%;\">\n<img src=\"icons_imgs/sashboard.png\" alt=\"\" style=\"height:100%; width:100%;\">\n\n</div>\n<div style=\"height:100%;width:33%;float:left;\">\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:45%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">\nAnalyse batch\n</p>\n</div>\n</a>\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:50%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p class=\"vcenter\" style=\"color:white;font-weight:900;\">\nAnalyse prédictive\n</p>\n</div>\n</a>\n</div>\n\n\n</div>\n\n\n\n\n<div style=\"float:left;width:50%;height:25vh;\">\n<div class=\"vcenter\" style=\"height:10%;width:100%;\">\n<p style=\"text-align:center;height:100%;color:white;font-weight:900;\">USAGE DES DONNEES</p>\n</div>\n\n<div  style=\"height:35vh;width:33%;float:left;\">\n\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:33%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">\nAnalyse batch\n</p>\n</div>\n</a>\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:33%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">\nAnalyse prédictive\n</p>\n</div>\n</a>\n\n</div>\n<div   style=\"height:100%;width:33%;float:left;padding:5%;\">\n<img src=\"icons_imgs/sashboard.png\" alt=\"\" style=\"height:100%; width:100%;\">\n\n</div>\n<div style=\"height:100%;width:33%;float:left;\">\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:45%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">\nAnalyse batch\n</p>\n</div>\n</a>\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:50%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p class=\"vcenter\" style=\"color:white;font-weight:900;\">\nAnalyse prédictive\n</p>\n</div>\n</a>\n</div>\n\n\n</div>\n\n\n\n<div style=\"float:left;width:100%;height:20vh;background-color:blue;\">\nall\n</div>\n\n\n\n\n\n</div>\n<div style=\"height:35vh;width:15vw;float:left;text-align:center;\">\n<div style=\"height:86%;width:15vw; text-align:center;\">\n<div class=\"vcenter\" style=\"height:10%;width:100%;\">\n<p style=\"text-align:center;height:100%;color:white;font-weight:900;\">COLLECTE</p>\n</div>\n<img src=\"icons_imgs/sashboard.png\" alt=\"\" style=\"height:60%; width:100%;padding-top:10%;padding-left:12%;padding-right:12%;\">\n<a href=\"#\">\n<div class=\"vcenter\" style=\"height:50%;width:100%;text-align:center;background-color:#3498db;border-bottom-style:solid;border-bottom-size:1px;\">\n<p style=\"color:#dcdde1;font-weight:900;\">Collecte de données en streaming</p>\n</div>\n</a>\n\n</div>\n</div>\n</div>\n\n\n<div   style=\"width:100vw;height:5vh;background-color:yellow;float:left !important;text-align:center;\">\ntest\n</div>\n<div   style=\"width:100vw;height:45vh;background-color:red;float:left !important;\">\n<div style=\"height:35vh;width:50vw;float:left;text-align:center;\">\ntest4\n</div>\n<div style=\"height:35vh;width:30vw;float:left;text-align:center;\">\ntest2\n</div>\n<div style=\"height:35vh;width:20vw;float:left;text-align:center;\">\ntest3\n</div>\n</div>\n\n\n</div> --> <div class=\"wrapper\"> <div class=\"zero\"> <img src=\"icons_imgs/SG.png\" height=\"20\" style=\"position:fixed;top:10px;right:20px\"> <img src=\"icons_imgs/logo_socle_big_data_v3.png\" style=\"position:fixed;top:0;left:45%;width:8%;height:12%;background-color:#fff;border-bottom-left-radius:10%;border-radius:10%;padding:4px;border-width:4px;border-style:solid;border-color:#95afc0\"> </div> <div class=\"one bleu\"> <div class=\"main_widget\"> <div class=\"header bleu\"> <strong> Collecte</strong> </div> <div class=\"icon-up\"> <img src=\"icons_imgs/Collecte.png\" alt=\"\" width=\"100\" height=\"100\"> </div> <a ui-sref=\"app.pageContent({contentPath:'collecte/streaming.md'})\" style=\"display:block\"> <div class=\"\" style=\"height:10vh;text-align:center;padding-top:5%;width:98%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Collecte de données en streaming</p> </div> </a> <a ui-sref=\"app.pageContent({contentPath:'collecte/streaming.md'})\" style=\"display:block\"> <div class=\"\" style=\"height:10vh;text-align:center;padding-top:5%;width:98%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Collecte de données en Batch</p> </div> </a> </div> </div> <div class=\"two asphalt\"> <div class=\"main_widget asphalt\"> <div class=\"header asphalt\"> Usage Des Données </div> <div class=\"asphalt\" style=\"height:90%;width:100%\"> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <a href=\"#\" style=\"display:block\"> <div class=\"asphalt\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Analyse Batch</p> </div> </a> <a href=\"#\" style=\"display:block\"> <div class=\"asphalt\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Analyse prédictive</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <div class=\"icon-up\" style=\"height:100%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <img src=\"icons_imgs/Usage.png\" alt=\"\" width=\"100\" height=\"100\"> </div> </div> <div class=\"asphalt\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <a href=\"#\" style=\"display:block\"> <div class=\"asphalt\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Analyse interactive</p> </div> </a> <a href=\"#\" style=\"display:block\"> <div class=\"asphalt\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">API</p> </div> </a> </div> </div> </div> </div> <div class=\"three midnight\"> <div class=\"main_widget\"> <div class=\"header\"> <strong>Vues</strong> </div> <div class=\"\" style=\"height:90%;width:100%\"> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <a href=\"#\" style=\"display:block\" ui-sref=\"app.pageContent({contentPath:'collecte/streaming.md'})\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Batch</p> </div> </a> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Interactif NoSQL</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <div class=\"icon-up\" style=\"height:100%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <img src=\"icons_imgs/Vues.png\" alt=\"\" width=\"100\" height=\"100\"> </div> </div> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Interactif Search Engine</p> </div> </a> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Temps réel</p> </div> </a> </div> </div> </div> </div> <div class=\"four bleu\"> <div class=\"main_widget\"> <div class=\"header\"> <strong>Data Lake</strong> </div> <div class=\"icon-up\"> <img src=\"icons_imgs/Datalake.png\" alt=\"\" width=\"100\" height=\"100\"> </div> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:10vh;text-align:center;padding-top:5%;width:98%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">DataLake</p> </div> </a> </div> </div> <div class=\"five soaring\"> <!-- <div class=\"row_widget\" >\n\n      <div class=\"header\">\n        Collecte\n      </div>\n       --> <div class=\"main_widget\"> <div class=\"header\"> <strong>Traitements</strong> </div> <div class=\"\" style=\"height:90%;width:100%\"> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <!-- <a href=\"#\" style=\"display:block;\">\n                        <div class=\" \" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display: block;\n                        vertical-align: middle\">\n                       <p style=\"color:#dcdde1;font-weight:800;\">Batch</p>\n                      </div>\n                    </a> --> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Traitements mode Batch</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <div class=\"\" style=\"height:100%;text-align:center;padding-top:2%;margin:1%;display:block;vertical-align:middle\"> <img src=\"icons_imgs/Traitement.png\" alt=\"\" style=\"height:auto;width:auto;max-width:50%;max-height:80px\"> </div> </div> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <!-- <a href=\"#\" style=\"display:block;\">\n                        <div class=\" \" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display: block;\n                        vertical-align: middle\">\n                        <p style=\"color:#dcdde1;font-weight:800;\">Interactif Search Engine</p>\n                      </div>\n                    </a> --> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Traitements mode Streaming</p> </div> </a> </div> </div> </div> <!-- <div class=\" left  \" style=\"width:33%;\" >\n        <div class=\" container_cases\" >\n\n        </div>\n      </div> --> <!-- <div class=\"  left\" >\n          <div class=\"container_cases \" >\n            <img class=\"middle-img\" src=\"icons_imgs/sashboard.png\" alt=\"\" style=\"\">\n          </div>\n      </div> --> <!-- <div class=\" \" style=\"float:left;width:33%;height:100%;\">\n          <div class=\"icon-up \" style=\"\">\n            <img src=\"icons_imgs/sashboard.png\" alt=\"\" width=\"100\" height=\"100\">\n          </div>\n      </div> --> <!-- <div class=\" \" style=\"float:left;width:33%;\">\n      </div> --> <!-- </div> --> </div> <!-- <div class=\"six\" >\n    <div class=\"center\">\n      <p>test</p>\n    </div>\n  </div> --> <div class=\"seven pink-glamour\"> <div class=\"main_widget\"> <div class=\"header\"> <strong>Data Management</strong> </div> <div class=\"\" style=\"height:90%;width:100%\"> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle;padding-top:5%\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Catalogue des données</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <div class=\"icon-up\" style=\"height:100%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <img src=\"icons_imgs/Data_management.png\" alt=\"\" width=\"100\" height=\"100\"> </div> </div> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle;padding-top:5%\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Data lineage</p> </div> </a> </div> </div> </div> </div> <div class=\"eight orange\"> <div class=\"main_widget\"> <div class=\"header\"> <strong>Développement</strong> </div> <div class=\"\" style=\"height:90%;width:100%\"> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle;padding-top:5%\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Continuous delivery</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <div class=\"icon-up\" style=\"height:100%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <img src=\"icons_imgs/Developpement.png\" alt=\"\" width=\"100\" height=\"100\"> </div> </div> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Environnements</p> </div> </a> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Outils de développement</p> </div> </a> </div> </div> </div> </div> <div class=\"nine golden\"> <div class=\"main_widget\"> <div class=\"header\"> <strong>Sécurité</strong> </div> <div class=\"icon-up-major\"> <img src=\"icons_imgs/Securite.png\" alt=\"\" width=\"100\" height=\"100\"> </div> <div class=\"\"> <div class=\"main_widget\"> <div class=\"\" style=\"height:90%;width:100%\"> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Désensibilisation</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Tracabilité</p> </div> </a> </div> <div class=\"\" style=\"float:left;width:33%;height:100%;vertical-align:middle\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle\"> <p style=\"color:#dcdde1;font-weight:800\">Habilitation</p> </div> </a> </div> </div> </div> </div> </div> </div> <div class=\"ten orange\"> <div class=\"main_widget\"> <div class=\"header\"> <strong>Exploitation</strong> </div> <div class=\"icon-up-major\"> <img src=\"icons_imgs/Exploitation.png\" alt=\"\" width=\"80\" height=\"100\"> </div> <div class=\"\"> <a href=\"#\" style=\"display:block\"> <div class=\"\" style=\"height:50%;text-align:center;padding-top:5%;margin:1%;display:block;vertical-align:middle;width:60%;margin-left:20%\"> <p style=\"color:#dcdde1;font-weight:800\">Secours</p> </div> </a> </div> </div> </div> </div> ";
                                                                                                                      // 6
      angular.module('angular-templates')                                                                             // 7
        .run(['$templateCache', function($templateCache) {                                                            // 8
          $templateCache.put(templateUrl, template);                                                                  // 9
        }]);                                                                                                          // 10
                                                                                                                      // 11
      module.exports = {};                                                                                            // 12
      module.exports.__esModule = true;                                                                               // 13
      module.exports.default = templateUrl;                                                                           // 14
                                                                                                                      // 15
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},"model":{"modelCtrl.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/components/model/modelCtrl.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// import {_} from 'meteor/underscore';                                                                               // 1
//                                                                                                                    // 2
// import {Meteor} from 'meteor/meteor';                                                                              // 3
// import moment from 'moment';                                                                                       // 4
// import {Controller} from 'angular-ecmascript/module-helpers';                                                      // 5
//                                                                                                                    // 6
// import { MessagesLanding } from '../../../../lib/collections';                                                     // 7
//                                                                                                                    // 8
// export default  class  ModelCtrl extends Controller {                                                              // 9
//   constructor(...args) {                                                                                           // 10
//     super(...args);                                                                                                // 11
//     this.$reactive(this).attach(this.$scope);                                                                      // 12
//     var self=this;                                                                                                 // 13
//     this.$rootScope.title="Mon titre";                                                                             // 14
//                                                                                                                    // 15
//                                                                                                                    // 16
//                                                                                                                    // 17
//     this.helpers({                                                                                                 // 18
//                                                                                                                    // 19
//                                                                                                                    // 20
//                                                                                                                    // 21
//         });                                                                                                        // 22
//                                                                                                                    // 23
//                                                                                                                    // 27
//   }                                                                                                                // 28
//                                                                                                                    // 29
//                                                                                                                    // 30
//                                                                                                                    // 31
//                                                                                                                    // 32
//                                                                                                                    // 33
// }                                                                                                                  // 34
// ModelCtrl.$inject = ['$aside','$location','$animate', '$state', '$reactive','$uibModal','$location','$anchorScroll','$rootScope'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"templates":{"sidemenu.html":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/templates/sidemenu.html                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
      if (Meteor.isServer) return;                                                                                    // 2
                                                                                                                      // 3
      var templateUrl = "/client/templates/sidemenu.html";                                                            // 4
      var template = "<!--\n  <nav  class=\"navbar navbar-dark navbar-fixed-top  \" >\n\n\n\n\n\n      <div class=\"col-lg-1 col-sm-1 col-xs-1 pull-left nav-icons \" aside-menu-toggle=\"left-menu\"  style=\"color:white;margin:0px 0px 0px 0px;height:10vh;padding-top:0px;padding-bottom:0px;border-radius:0px;width:10vh;text-align:center;font-size:2em;line-height:10vh;\">\n        <span class=\"fa fa-align-left \" >\n\n        </span>\n      </div>\n\n      <div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6\" >\n\n        <p style=\"color:white\">{{title}}</p>\n\n      </div>\n\n\n  </nav>\n --> <ui-view name=\"side-menu-content\"> </ui-view> ";
                                                                                                                      // 6
      angular.module('angular-templates')                                                                             // 7
        .run(['$templateCache', function($templateCache) {                                                            // 8
          $templateCache.put(templateUrl, template);                                                                  // 9
        }]);                                                                                                          // 10
                                                                                                                      // 11
      module.exports = {};                                                                                            // 12
      module.exports.__esModule = true;                                                                               // 13
      module.exports.default = templateUrl;                                                                           // 14
                                                                                                                      // 15
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"index.html.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// client/index.html.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
                                                                                                                      // 1
            Meteor.startup(function() {                                                                               // 2
              var attrs = {"ui-view":""};                                                                             // 3
              for (var prop in attrs) {                                                                               // 4
                document.body.setAttribute(prop, attrs[prop]);                                                        // 5
              }                                                                                                       // 6
            });                                                                                                       // 7
                                                                                                                      // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"lib":{"collections.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/collections.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({                                                                                                       // 1
  MessagesLanding: function () {                                                                                      // 1
    return MessagesLanding;                                                                                           // 1
  }                                                                                                                   // 1
});                                                                                                                   // 1
var Mongo = void 0;                                                                                                   // 1
module.watch(require("meteor/mongo"), {                                                                               // 1
  Mongo: function (v) {                                                                                               // 1
    Mongo = v;                                                                                                        // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 1);                                                                                                                // 1
var MessagesLanding = new Mongo.Collection("messages_landing");                                                       // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".html",
    ".css"
  ]
});
require("./client/scripts/lib/app.js");
require("./lib/collections.js");
require("./client/components/carre/PageContent/controller/PageContent.controller.js");
require("./client/components/carre/PageContent/templates/PageContent.html");
require("./client/components/carre/home/controller/home.controller.js");
require("./client/components/carre/home/templates/home.html");
require("./client/components/model/modelCtrl.js");
require("./client/scripts/controllers/app.controller.js");
require("./client/scripts/directives/navbar.directive.js");
require("./client/scripts/factorys/inboxCount.factory.js");
require("./client/scripts/filters/calendar.filter.js");
require("./client/scripts/sevices/inboxCount.factory.js");
require("./client/scripts/sevices/readFile.factory.js");
require("./client/scripts/config.js");
require("./client/scripts/route_runs.js");
require("./client/scripts/routes.js");
require("./client/templates/sidemenu.html");
require("./client/index.html.js");