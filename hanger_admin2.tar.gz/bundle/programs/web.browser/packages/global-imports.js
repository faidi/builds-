/* Imports for global scope */

Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
BootstrapModalPrompt = Package['theduke:bootstrap-modal-prompt'].BootstrapModalPrompt;
Accounts = Package['accounts-base'].Accounts;
HTTP = Package.http.HTTP;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
_ = Package.underscore._;
DDP = Package['ddp-client'].DDP;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
process = Package.modules.process;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
Autoupdate = Package.autoupdate.Autoupdate;
Reload = Package.reload.Reload;
Symbol = Package['ecmascript-runtime-client'].Symbol;
Map = Package['ecmascript-runtime-client'].Map;
Set = Package['ecmascript-runtime-client'].Set;

