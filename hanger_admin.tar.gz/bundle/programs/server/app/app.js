var require = meteorInstall({"lib":{"collections.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// lib/collections.js                                                                                   //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
module.export({                                                                                         // 1
  MessagesLanding: function () {                                                                        // 1
    return MessagesLanding;                                                                             // 1
  }                                                                                                     // 1
});                                                                                                     // 1
var Mongo = void 0;                                                                                     // 1
module.watch(require("meteor/mongo"), {                                                                 // 1
  Mongo: function (v) {                                                                                 // 1
    Mongo = v;                                                                                          // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
var MessagesLanding = new Mongo.Collection("messages_landing");                                         // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"carree":{"home_methods.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// server/carree/home_methods.js                                                                        //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var HTTP = void 0;                                                                                      // 1
module.watch(require("meteor/http"), {                                                                  // 1
  HTTP: function (v) {                                                                                  // 1
    HTTP = v;                                                                                           // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
Meteor.methods({                                                                                        // 3
  getFile: function (filePath) {                                                                        // 5
    console.log("chargement du fichier");                                                               // 6
    this.unblock();                                                                                     // 7
    var response;                                                                                       // 8
                                                                                                        //
    try {                                                                                               // 9
      response = HTTP.call('GET', 'https://raw.githubusercontent.com/faidi/Carree/master/' + filePath);
    } catch (e) {                                                                                       // 12
      response = e.response;                                                                            // 13
    } finally {                                                                                         // 14
      console.log(response);                                                                            // 15
      return response.content;                                                                          // 16
    } // // HTTP.call( 'GET',                                                                           // 17
    //    'https://raw.githubusercontent.com/faidi/Carree/master/README.md',                            // 19
    //     {},                                                                                          // 20
    //    function( error, response )                                                                   // 21
    //    {                                                                                             // 22
    //            if ( error ) {                                                                        // 23
    //              console.log( error );                                                               // 24
    //              return error;                                                                       // 25
    //            }                                                                                     // 26
    //            else {                                                                                // 27
    //              console.log( response);                                                             // 28
    //              return response.content;                                                            // 29
    //            }                                                                                     // 30
    //    }                                                                                             // 31
    //      );                                                                                          // 32
                                                                                                        //
  }                                                                                                     // 36
});                                                                                                     // 3
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"landing":{"contact_landing.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// server/landing/contact_landing.js                                                                    //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var MessagesLanding = void 0;                                                                           // 1
module.watch(require("../../lib/collections"), {                                                        // 1
  MessagesLanding: function (v) {                                                                       // 1
    MessagesLanding = v;                                                                                // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
Meteor.methods({                                                                                        // 4
  sendContactMessage: function (data) {                                                                 // 5
    var id = MessagesLanding.insert(data);                                                              // 6
    console.log(id);                                                                                    // 7
    return id;                                                                                          // 8
  },                                                                                                    // 9
  openMessage: function (data) {                                                                        // 10
    console.log(data);                                                                                  // 11
    var id = MessagesLanding.update({                                                                   // 12
      _id: data                                                                                         // 12
    }, {                                                                                                // 12
      $set: {                                                                                           // 12
        readed: true                                                                                    // 12
      }                                                                                                 // 12
    });                                                                                                 // 12
    console.log(id);                                                                                    // 13
    return id;                                                                                          // 14
  },                                                                                                    // 15
  getMessagesCount: function () {                                                                       // 16
    console.log("tapped");                                                                              // 17
    return MessagesLanding.find({}).count();                                                            // 18
  },                                                                                                    // 19
  getUnreadMessagesCount: function () {                                                                 // 20
    console.log("tapped2");                                                                             // 21
    return MessagesLanding.find({                                                                       // 22
      readed: false                                                                                     // 22
    }).count();                                                                                         // 22
  }                                                                                                     // 23
});                                                                                                     // 4
//////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications_messages.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// server/landing/publications_messages.js                                                              //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var MessagesLanding = void 0;                                                                           // 1
module.watch(require("../../lib/collections"), {                                                        // 1
  MessagesLanding: function (v) {                                                                       // 1
    MessagesLanding = v;                                                                                // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
Meteor.publish('messages', function () {                                                                // 4
  var data = MessagesLanding.find({});                                                                  // 6
                                                                                                        //
  if (data) {                                                                                           // 8
    return data;                                                                                        // 9
  }                                                                                                     // 10
                                                                                                        //
  return this.ready();                                                                                  // 12
});                                                                                                     // 13
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// server/main.js                                                                                       //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
var Meteor = void 0;                                                                                    // 1
module.watch(require("meteor/meteor"), {                                                                // 1
  Meteor: function (v) {                                                                                // 1
    Meteor = v;                                                                                         // 1
  }                                                                                                     // 1
}, 0);                                                                                                  // 1
var Accounts = void 0;                                                                                  // 1
module.watch(require("meteor/accounts-base"), {                                                         // 1
  Accounts: function (v) {                                                                              // 1
    Accounts = v;                                                                                       // 1
  }                                                                                                     // 1
}, 1);                                                                                                  // 1
Meteor.startup(function () {                                                                            // 4
  // code to run on server at startup                                                                   // 5
  if (Meteor.users.find({                                                                               // 8
    "profile.type": "admin"                                                                             // 8
  }).count() < 2) {                                                                                     // 8
    // Accounts.createUser({                                                                            // 9
    //        username: 'william',                                                                      // 10
    //        email: 'william@hanger.com',                                                              // 11
    //        password: 'william',                                                                      // 12
    //        profile:                                                                                  // 13
    //        {                                                                                         // 14
    //            firstname: 'William',                                                                 // 15
    //            lastname: 'William',                                                                  // 16
    //            phone:"33651303113",                                                                  // 17
    //            type: 'admin',                                                                        // 18
    //                                                                                                  // 19
    //                                                                                                  // 20
    //                                                                                                  // 21
    //         }                                                                                        // 22
    //        }                                                                                         // 23
    // );                                                                                               // 24
    console.log("created admin 1");                                                                     // 25
    Accounts.createUser({                                                                               // 26
      username: 'zied',                                                                                 // 27
      email: 'zied@hanger.com',                                                                         // 28
      password: 'zied',                                                                                 // 29
      profile: {                                                                                        // 30
        firstname: 'William',                                                                           // 32
        lastname: 'William',                                                                            // 33
        phone: "33651303113",                                                                           // 34
        type: 'admin'                                                                                   // 35
      }                                                                                                 // 31
    });                                                                                                 // 26
    console.log("created admin 2");                                                                     // 42
  }                                                                                                     // 44
});                                                                                                     // 47
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".html"
  ]
});
require("./lib/collections.js");
require("./server/carree/home_methods.js");
require("./server/landing/contact_landing.js");
require("./server/landing/publications_messages.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
